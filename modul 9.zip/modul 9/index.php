<form action="proses.php?aksi=tambah" method="post" enctype=”multipart/form-data”> 
<head>
<link href="css/a.css" rel="stylesheet">
</head>
<center>
<br><br>
<h2>Silahkan Input data </h2>
<br>
<br>
<table class="input">
    <tr>
        <td>Nama</td>
        <td><input type="text" name="nama" class="inputt"></td>
    </tr>
    <tr>
        <td>Alamat</td>
        <td><input type="text" name="alamat" class="inputt"></td>
    </tr>
    <tr>
        <td>Logo</td>
        <td>
            <input type="file" name="logo">
        </td>
    </tr>
    
    </table>
	 <td><input type="submit" value="Simpan" class="button"></td>
	 <td><a href="tampil.php"  class="button"> Tabel </a></td>
	</center>
</form>